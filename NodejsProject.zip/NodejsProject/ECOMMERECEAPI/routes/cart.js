// routes/user.js

const { verifyToken,verifyTokenAndAdmin, verifyTokenAndAuthorization } = require("./verifyToken");
const  Cart= require("../models/Cart"); 
const CryptoJS = require("crypto-js");
const router = require("express").Router();


router.post("/",verifyToken,async (req,res)=>{
    const newCart=new Cart(req.body);
    try{
        const savedProduct=await newCart.save();
        res.status(200).json(savedProduct)
    }
    catch(e){
        res.status(200).json(e)
    }
})





router.put("/:id", verifyTokenAndAuthorization, async (req, res) => {
    
    try {
        const updatedCart = await Cart.findByIdAndUpdate(
            req.params.id,
            { $set: req.body },
            { new: true }
        );
        res.status(200).json(updatedCart);
    } catch (err) {
        console.error("Error updating user:", err);
        res.status(500).json(err);
    }
});


router.delete("/:id", verifyTokenAndAuthorization, async (req, res) => {
    
    try{
        
        await Cart.findByIdAndDelete(req.params.id);

        res.status(200).json("Product has been deleted...");
    }
    catch(e){
        res.status(500).json(err);    }
});

router.get("/find/:userId",verifyTokenAndAuthorization, async (req, res) => {
    
    try{
        
        const product=await Cart.findOne({userId:req.params.userId});
        res.status(200).json(product)
    }
    catch(e){
        res.status(500).json(err);    }
});

//GET ALL CARTS

router.get("/",verifyTokenAndAdmin, async (req, res) => {
    
    try{
        const carts=await Cart.find();
        res.status(200).json(carts)
    }
    catch(e){
        res.status(500).json(err);    }
});

module.exports = router;
